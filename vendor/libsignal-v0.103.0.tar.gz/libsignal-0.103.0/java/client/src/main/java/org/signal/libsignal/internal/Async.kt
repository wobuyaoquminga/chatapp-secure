/*
 * Copyright 2025 Signal Messenger, LLC
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package org.signal.libsignal.internal

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Awaits for completion of this CompletableFuture without blocking a thread.
 *
 * This suspending function is cancellable. If the coroutine is cancelled while
 * this function is suspended, the future will be cancelled as well.
 *
 * @return The result value of the CompletableFuture
 * @throws Exception if the CompletableFuture completed exceptionally
 * @throws CancellationException if the coroutine was cancelled
 */
public suspend fun <T> CompletableFuture<T>.await(): T =
  suspendCancellableCoroutine { c ->
    // From https://kotlinlang.org/api/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines/-cancellable-continuation/
    val future = this
    future.whenComplete { result, throwable ->
      if (throwable != null) {
        // Resume continuation with an exception if an external source failed
        c.resumeWithException(throwable)
      } else {
        // Resume continuation with a value if it was computed
        c.resume(result)
      }
    }
    // Cancel the computation if the continuation itself was cancelled because a caller of 'await' is cancelled
    c.invokeOnCancellation {
      future.cancel(true)
    }
  }

/**
 * Transforms a CompletableFuture<T> into a CompletableFuture<R> with proper bidirectional cancellation.
 *
 * This helper wraps a native future and transforms its result, while ensuring that:
 * - Success values are transformed using the provided mapper
 * - CancellationExceptions propagate as cancellations (not completions)
 * - Other exceptions are transformed using the error mapper
 * - Cancellation of the outer future cancels the inner future
 *
 * @param onSuccess Function to transform success values from T to R
 * @param onError Function to transform non-cancellation exceptions to R
 * @return A new CompletableFuture<R> with bidirectional cancellation support
 */
public fun <T, R> CompletableFuture<T>.mapWithCancellation(
  onSuccess: (T) -> R,
  onError: (Throwable) -> R,
): CompletableFuture<R> {
  val outer = CompletableFuture<R>()

  this.whenComplete { value, err ->
    when (err) {
      null ->
        try {
          outer.complete(onSuccess(value))
        } catch (e: Exception) {
          outer.completeExceptionally(e)
        }

      is CancellationException -> outer.cancel(true)
      else ->
        try {
          outer.complete(onError(err))
        } catch (e: Exception) {
          outer.completeExceptionally(e)
        }
    }
  }

  outer.whenComplete { _, t ->
    if (t is CancellationException) {
      this.cancel(true)
    }
  }

  return outer
}

/**
 * Converts a `CompletableFuture<T>` to a `CompletableFuture<Result<T>>`.
 *
 * This helper function wraps the result of a CompletableFuture in a Result,
 * catching any exceptions and converting them to `Result.failure()`.
 *
 * Uses libsignal's chaining mechanism to ensure proper bidirectional cancellation
 * propagation for long async operations, like network requests.
 *
 * @return A new CompletableFuture that completes with `Result.success(value)` or `Result.failure(exception)`
 */
public fun <T> CompletableFuture<T>.toResultFuture(): CompletableFuture<Result<T>> =
  this.handle { value, throwable ->
    if (throwable == null) {
      Result.success(value)
    } else {
      Result.failure(throwable)
    }
  }

/**
 * Produces a `Flow` from a bulk-pull stream implementation.
 *
 * Not intended to be called outside of libsignal.
 *
 * The resulting `Flow` can only be collected once; trying to collect it multiple times will throw
 * [IllegalStateException]. Runs `cancel` if the flow is cancelled or produces an exception during
 * collection.
 */
public fun <T, S, RawItem> wrapStream(
  asyncContext: TokioAsyncContext,
  stream: S,
  pull: (TokioAsyncContext, S) -> CompletableFuture<Pair<List<RawItem>, Any?>>,
  convertItem: (RawItem) -> T,
  cancel: (S) -> Unit,
): Flow<T> {
  var consumed = AtomicBoolean(false)
  return flow {
    // Based on Kotlin's ReceiveChannel<T>.consumeAsFlow
    // https://github.com/Kotlin/kotlinx.coroutines/blob/165c6cb5859b5365dec193abc75dee9f49ce1389/kotlinx-coroutines-core/common/src/flow/Channels.kt#L104
    if (consumed.getAndSet(true)) {
      throw IllegalStateException("cannot consume libsignal flow multiple times")
    }
    while (true) {
      val (nextChunk, termination) = pull(asyncContext, stream).await()
      emitAll(nextChunk.asFlow().map(convertItem))
      if (termination != null) {
        when (termination) {
          is Unit -> break
          is Throwable -> throw termination
          else -> throw AssertionError("bad stream termination: $termination")
        }
      }
    }
  }.onCompletion {
    if (it != null) {
      cancel(stream)
    }
  }
}
