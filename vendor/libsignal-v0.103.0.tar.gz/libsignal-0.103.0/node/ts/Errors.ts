//
// Copyright 2021 Signal Messenger, LLC.
// SPDX-License-Identifier: AGPL-3.0-only
//

import { ProtocolAddress, ServiceId } from './Address.js';
import * as Native from './Native.js';
import { newNativeHandle } from './internal.js';
import {
  convertNativeRegistrationSessionState,
  RegistrationSessionState,
} from './net/RegistrationSession.js';

export enum ErrorCode {
  Generic,

  DuplicatedMessage,
  SealedSenderSelfSend,
  UntrustedIdentity,
  InvalidRegistrationId,
  InvalidProtocolAddress,
  VerificationFailed,
  InvalidSession,
  InvalidSenderKeySession,

  NicknameCannotBeEmpty,
  CannotStartWithDigit,
  MissingSeparator,
  BadNicknameCharacter,
  NicknameTooShort,
  NicknameTooLong,
  DiscriminatorCannotBeEmpty,
  DiscriminatorCannotBeZero,
  DiscriminatorCannotBeSingleDigit,
  DiscriminatorCannotHaveLeadingZeros,
  BadDiscriminatorCharacter,
  DiscriminatorTooLarge,

  IoError,
  CdsiInvalidToken,
  InvalidUri,

  InvalidMediaInput,
  UnsupportedMediaInput,

  InputDataTooLong,
  InvalidEntropyDataLength,
  InvalidUsernameLinkEncryptedData,

  RateLimitedError,
  RateLimitChallengeError,

  SvrDataMissing,
  SvrRequestFailed,
  SvrRestoreFailed,
  SvrAttestationError,
  SvrInvalidData,
  SvrDataMismatch,

  ChatServiceInactive,
  AppExpired,
  DeviceDelinked,
  ConnectionInvalidated,
  ConnectedElsewhere,
  PossibleCaptiveNetwork,

  BackupValidation,

  Cancelled,

  KeyTransparencyError,
  KeyTransparencyVerificationFailed,

  IncrementalMacVerificationFailed,

  RequestUnauthorized,
  MismatchedDevices,

  ServiceIdNotFound,
  DeviceIdNotFound,

  UploadTooLarge,

  RegisterAccountRequestRejected,
  RegistrationCredentialsCouldNotBeParsed,
  RegistrationDeviceTransferPossibleNotSkipped,
  RegistrationInvalidReceipt,
  RegistrationInvalidSession,
  RegistrationLock,
  RegistrationOneTimePasswordRequired,
  RegistrationRecoveryPasswordRequired,
  RegistrationRecoveryVerificationFailed,
  RegistrationRequestInvalid,
  RegistrationRequestRejected,
  RegistrationSessionIdInvalid,
  RegistrationSessionNotFound,
  RegistrationSessionNotReadyForVerification,
  RegistrationVerificationCodeNotDeliverable,
  RegistrationVerificationSendFailed,

  UsernameNotAvailable,
  UsernameNotSet,
  UsernameReservationNotFound,

  InvalidReceipt,
  MissingBackupId,

  ReceiptCredentialErrorPaymentStillProcessing,
  ReceiptCredentialErrorPaymentRequired,
  ReceiptCredentialErrorPaymentNotFound,
  ReceiptCredentialErrorReceiptAlreadyIssued,
  TooManyTotpKeys,
  TooManyMfaKeys,
  MfaNotVerified,
  /** @deprecated Use {@link MfaNotVerified} instead. */
  OneTimePasswordNotVerified = MfaNotVerified,
  MfaKeyNotFound,
  WebAuthnRegistrationUnsuccessful,
}

/** Called out as a separate type so it's not confused with a normal ServiceIdBinary. */
type ServiceIdFixedWidthBinary = Uint8Array<ArrayBuffer>;

/**
 * A failure sending to a recipient on account of not being up to date on their devices.
 *
 * An entry in {@link MismatchedDevicesError}. Each entry represents a recipient that has either
 * added, removed, or relinked some devices in their account (potentially including their primary
 * device), as represented by the {@link MismatchedDevicesEntry#missingDevices},
 * {@link MismatchedDevicesEntry#extraDevices}, and {@link MismatchedDevicesEntry#staleDevices}
 * arrays, respectively. Handling the exception involves removing the "extra" devices and
 * establishing new sessions for the "missing" and "stale" devices.
 */
export class MismatchedDevicesEntry {
  account: ServiceId;
  missingDevices: number[];
  extraDevices: number[];
  staleDevices: number[];

  constructor({
    account,
    missingDevices,
    extraDevices,
    staleDevices,
  }: {
    account: ServiceId | ServiceIdFixedWidthBinary;
    missingDevices?: number[];
    extraDevices?: number[];
    staleDevices?: number[];
  }) {
    this.account =
      account instanceof ServiceId
        ? account
        : ServiceId.parseFromServiceIdFixedWidthBinary(account);
    this.missingDevices = missingDevices ?? [];
    this.extraDevices = extraDevices ?? [];
    this.staleDevices = staleDevices ?? [];
  }
}

export type PaymentProvider =
  | 'googlePlayBilling'
  | 'appleAppStore'
  | 'stripe'
  | 'braintree';
export type ChargeFailure = {
  processor: PaymentProvider;
  code: string;
  message: string;
  outcomeNetworkStatus: string | null;
  outcomeReason: string | null;
  outcomeType: string | null;
};

export class LibSignalErrorBase extends Error {
  public readonly code: ErrorCode;
  public readonly operation: string;
  readonly _addr?: string | Native.ProtocolAddress;
  readonly _sessionState?: Native.RegistrationSession;
  readonly _chargeFailure?: ChargeFailure | null;

  constructor(
    message: string,
    name: keyof typeof ErrorCode | undefined,
    operation: string,
    extraProps?: Record<string, unknown>
  ) {
    super(message);
    // Include the dynamic check for `name in ErrorCode` in case there's a bug in the Rust code.
    if (name !== undefined && name in ErrorCode) {
      this.name = name;
      this.code = ErrorCode[name];
    } else {
      this.name = 'LibSignalError';
      this.code = ErrorCode.Generic;
    }
    this.operation = operation;
    if (extraProps !== undefined) {
      Object.assign(this, extraProps);
    }

    // Maintains proper stack trace, where our error was thrown (only available on V8)
    //   via https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this);
    }
  }

  public get addr(): ProtocolAddress | string {
    switch (this.code) {
      case ErrorCode.UntrustedIdentity:
        return this._addr as string;
      case ErrorCode.InvalidRegistrationId:
        return ProtocolAddress._fromNativeHandle(
          this._addr as Native.ProtocolAddress
        );
      default:
        throw new TypeError(`cannot get address from this error (${this})`);
    }
  }

  public get sessionState(): RegistrationSessionState | undefined {
    if (this._sessionState === undefined) {
      return undefined;
    }
    return convertNativeRegistrationSessionState(
      newNativeHandle(this._sessionState)
    );
  }

  public get chargeFailure(): ChargeFailure | null {
    if (this._chargeFailure === undefined)
      throw new TypeError(`cannot get ChargeFailure from this error (${this})`);
    return this._chargeFailure;
  }

  public toString(): string {
    return `${this.name} - ${this.operation}: ${this.message}`;
  }

  /// Like `error.code === code`, but also providing access to any additional properties.
  public is<E extends ErrorCode>(
    code: E
  ): this is Extract<LibSignalError, { code: E }> {
    return this.code === code;
  }

  /// Like `error instanceof LibSignalErrorBase && error.code === code`, but all in one expression,
  /// and providing access to any additional properties.
  public static is<E extends ErrorCode>(
    error: unknown,
    code: E
  ): error is Extract<LibSignalError, { code: E }> {
    if (error instanceof LibSignalErrorBase) {
      return error.is(code);
    }
    return false;
  }
}

export type LibSignalErrorCommon = Omit<
  LibSignalErrorBase,
  'addr' | 'chargeFailure'
>;

export type GenericError = LibSignalErrorCommon & {
  code: ErrorCode.Generic;
};

export type DuplicatedMessageError = LibSignalErrorCommon & {
  code: ErrorCode.DuplicatedMessage;
};

export type SealedSenderSelfSendError = LibSignalErrorCommon & {
  code: ErrorCode.SealedSenderSelfSend;
};

export type UntrustedIdentityError = LibSignalErrorCommon & {
  code: ErrorCode.UntrustedIdentity;
  addr: string;
};

export type InvalidRegistrationIdError = LibSignalErrorCommon & {
  code: ErrorCode.InvalidRegistrationId;
  addr: ProtocolAddress;
};

export type InvalidProtocolAddress = LibSignalErrorCommon & {
  code: ErrorCode.InvalidProtocolAddress;
  name: string;
  deviceId: number;
};

export type VerificationFailedError = LibSignalErrorCommon & {
  code: ErrorCode.VerificationFailed;
};

export type InvalidSessionError = LibSignalErrorCommon & {
  code: ErrorCode.InvalidSession;
};

export type InvalidSenderKeySessionError = LibSignalErrorCommon & {
  code: ErrorCode.InvalidSenderKeySession;
  distributionId: string;
};

export type NicknameCannotBeEmptyError = LibSignalErrorCommon & {
  code: ErrorCode.NicknameCannotBeEmpty;
};
export type CannotStartWithDigitError = LibSignalErrorCommon & {
  code: ErrorCode.CannotStartWithDigit;
};
export type MissingSeparatorError = LibSignalErrorCommon & {
  code: ErrorCode.MissingSeparator;
};

export type BadNicknameCharacterError = LibSignalErrorCommon & {
  code: ErrorCode.BadNicknameCharacter;
};

export type NicknameTooShortError = LibSignalErrorCommon & {
  code: ErrorCode.NicknameTooShort;
};

export type NicknameTooLongError = LibSignalErrorCommon & {
  code: ErrorCode.NicknameTooLong;
};

export type DiscriminatorCannotBeEmptyError = LibSignalErrorCommon & {
  code: ErrorCode.DiscriminatorCannotBeEmpty;
};
export type DiscriminatorCannotBeZeroError = LibSignalErrorCommon & {
  code: ErrorCode.DiscriminatorCannotBeZero;
};
export type DiscriminatorCannotBeSingleDigitError = LibSignalErrorCommon & {
  code: ErrorCode.DiscriminatorCannotBeSingleDigit;
};
export type DiscriminatorCannotHaveLeadingZerosError = LibSignalErrorCommon & {
  code: ErrorCode.DiscriminatorCannotHaveLeadingZeros;
};
export type BadDiscriminatorCharacterError = LibSignalErrorCommon & {
  code: ErrorCode.BadDiscriminatorCharacter;
};
export type DiscriminatorTooLargeError = LibSignalErrorCommon & {
  code: ErrorCode.DiscriminatorTooLarge;
};

export type InputDataTooLong = LibSignalErrorCommon & {
  code: ErrorCode.InputDataTooLong;
};

export type InvalidEntropyDataLength = LibSignalErrorCommon & {
  code: ErrorCode.InvalidEntropyDataLength;
};

export type InvalidUsernameLinkEncryptedData = LibSignalErrorCommon & {
  code: ErrorCode.InvalidUsernameLinkEncryptedData;
};

export type IoError = LibSignalErrorCommon & {
  code: ErrorCode.IoError;
};

export type CdsiInvalidTokenError = LibSignalErrorCommon & {
  code: ErrorCode.CdsiInvalidToken;
};

export type InvalidUriError = LibSignalErrorCommon & {
  code: ErrorCode.InvalidUri;
};

export type InvalidMediaInputError = LibSignalErrorCommon & {
  code: ErrorCode.InvalidMediaInput;
};

export type UnsupportedMediaInputError = LibSignalErrorCommon & {
  code: ErrorCode.UnsupportedMediaInput;
};

export type RateLimitedError = LibSignalErrorBase & {
  code: ErrorCode.RateLimitedError;
  readonly retryAfterSecs: number;
};

export type RateLimitChallengeError = LibSignalErrorBase & {
  code: ErrorCode.RateLimitChallengeError;
  readonly token: string;
  readonly options: Set<'pushChallenge' | 'captcha'>;
  readonly retryAfterSecs: number | null;
};

export type ChatServiceInactive = LibSignalErrorBase & {
  code: ErrorCode.ChatServiceInactive;
};

export type AppExpiredError = LibSignalErrorBase & {
  code: ErrorCode.AppExpired;
};

export type DeviceDelinkedError = LibSignalErrorBase & {
  code: ErrorCode.DeviceDelinked;
};

export type ConnectionInvalidatedError = LibSignalErrorBase & {
  code: ErrorCode.ConnectionInvalidated;
};

export type ConnectedElsewhereError = LibSignalErrorBase & {
  code: ErrorCode.ConnectedElsewhere;
};

export type PossibleCaptiveNetworkError = LibSignalErrorBase & {
  code: ErrorCode.PossibleCaptiveNetwork;
};

export type SvrDataMissingError = LibSignalErrorBase & {
  code: ErrorCode.SvrDataMissing;
};

export type SvrRequestFailedError = LibSignalErrorCommon & {
  code: ErrorCode.SvrRequestFailed;
};

export type SvrRestoreFailedError = LibSignalErrorCommon & {
  code: ErrorCode.SvrRestoreFailed;
  readonly triesRemaining: number;
};

export type SvrAttestationError = LibSignalErrorCommon & {
  code: ErrorCode.SvrAttestationError;
};

export type SvrInvalidDataError = LibSignalErrorCommon & {
  code: ErrorCode.SvrInvalidData;
};

export type SvrDataMismatchError = LibSignalErrorCommon & {
  code: ErrorCode.SvrDataMismatch;
};

export type BackupValidationError = LibSignalErrorCommon & {
  code: ErrorCode.BackupValidation;
  readonly unknownFields: ReadonlyArray<string>;
};

export type CancellationError = LibSignalErrorCommon & {
  code: ErrorCode.Cancelled;
};

export type KeyTransparencyError = LibSignalErrorCommon & {
  code: ErrorCode.KeyTransparencyError;
};

export type KeyTransparencyVerificationFailed = LibSignalErrorCommon & {
  code: ErrorCode.KeyTransparencyVerificationFailed;
};

export type IncrementalMacVerificationFailed = LibSignalErrorCommon & {
  code: ErrorCode.IncrementalMacVerificationFailed;
};

export type RequestUnauthorizedError = LibSignalErrorCommon & {
  code: ErrorCode.RequestUnauthorized;
};

export type MismatchedDevicesError = LibSignalErrorCommon & {
  code: ErrorCode.MismatchedDevices;
  readonly entries: MismatchedDevicesEntry[];
};

export type ServiceIdNotFound = LibSignalErrorCommon & {
  code: ErrorCode.ServiceIdNotFound;
};

export type UploadTooLarge = LibSignalErrorCommon & {
  code: ErrorCode.UploadTooLarge;
};

export type RegistrationSessionNotFoundError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationSessionNotFound;
};

export type RegistrationSessionIdInvalidError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationSessionIdInvalid;
};

export type RegistrationRequestInvalidError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationRequestInvalid;
};

export type RegistrationRequestRejectedError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationRequestRejected;
};

export type RegistrationSessionNotReadyForVerificationError =
  LibSignalErrorCommon & {
    code: ErrorCode.RegistrationSessionNotReadyForVerification;
    readonly sessionState?: RegistrationSessionState;
  };

export type RegistrationVerificationSendFailedError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationVerificationSendFailed;
  readonly sessionState?: RegistrationSessionState;
};

export type RegistrationVerificationCodeNotDeliverableError =
  LibSignalErrorCommon & {
    code: ErrorCode.RegistrationVerificationCodeNotDeliverable;
    readonly reason: string;
    readonly permanentFailure: boolean;
  };

export type RegistrationLockError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationLock;
  readonly timeRemainingSeconds: number;
  // null when the existing lock has no associated SVR2 secret.
  readonly svr2Username: string | null;
  readonly svr2Password: string | null;
};

export type RegistrationDeviceTransferPossibleNotSkippedError =
  LibSignalErrorCommon & {
    code: ErrorCode.RegistrationDeviceTransferPossibleNotSkipped;
  };

export type RegistrationOneTimePasswordRequiredError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationOneTimePasswordRequired;
};

export type RegistrationRecoveryPasswordRequiredError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationRecoveryPasswordRequired;
};

export type RegistrationRecoveryVerificationFailedError =
  LibSignalErrorCommon & {
    code: ErrorCode.RegistrationRecoveryVerificationFailed;
  };

export type RegisterAccountRequestRejectedError = LibSignalErrorCommon & {
  code: ErrorCode.RegisterAccountRequestRejected;
};

export type RegistrationCredentialsCouldNotBeParsedError =
  LibSignalErrorCommon & {
    code: ErrorCode.RegistrationCredentialsCouldNotBeParsed;
  };

export type RegistrationInvalidSessionError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationInvalidSession;
};

export type RegistrationInvalidReceiptError = LibSignalErrorCommon & {
  code: ErrorCode.RegistrationInvalidReceipt;
};

export type DeviceIdNotFound = LibSignalErrorCommon & {
  code: ErrorCode.DeviceIdNotFound;
};

export type UsernameNotAvailable = LibSignalErrorCommon & {
  code: ErrorCode.UsernameNotAvailable;
};

/**
 * @throws {ChatServiceInactive} if the chat connection has been closed.
 * @throws {IoError} if an error occurred while communicating with the server.
 * @throws {RateLimitedError} if the server is rate limiting this client. This is **retryable**
 * after waiting the designated delay.
 */
export type StandardNetworkError =
  | ChatServiceInactive
  | IoError
  | RateLimitedError;

export type UsernameNotSet = LibSignalErrorCommon & {
  code: ErrorCode.UsernameNotSet;
};

export type UsernameReservationNotFound = LibSignalErrorCommon & {
  code: ErrorCode.UsernameReservationNotFound;
};

export type InvalidReceiptError = LibSignalErrorCommon & {
  code: ErrorCode.InvalidReceipt;
};

export type MissingBackupId = LibSignalErrorCommon & {
  code: ErrorCode.MissingBackupId;
};

export type ReceiptCredentialErrorPaymentStillProcessing =
  LibSignalErrorCommon & {
    code: ErrorCode.ReceiptCredentialErrorPaymentStillProcessing;
  };
export type ReceiptCredentialErrorPaymentRequired = LibSignalErrorCommon & {
  code: ErrorCode.ReceiptCredentialErrorPaymentRequired;
  readonly chargeFailure: ChargeFailure | null;
};
export type ReceiptCredentialErrorPaymentNotFound = LibSignalErrorCommon & {
  code: ErrorCode.ReceiptCredentialErrorPaymentNotFound;
};
export type ReceiptCredentialErrorReceiptAlreadyIssued =
  LibSignalErrorCommon & {
    code: ErrorCode.ReceiptCredentialErrorReceiptAlreadyIssued;
  };
export type TooManyTotpKeys = LibSignalErrorCommon & {
  code: ErrorCode.TooManyTotpKeys;
};

export type TooManyMfaKeys = LibSignalErrorCommon & {
  code: ErrorCode.TooManyMfaKeys;
};

export type MfaNotVerified = LibSignalErrorCommon & {
  code: ErrorCode.MfaNotVerified;
};
/** @deprecated Use {@link MfaNotVerified} instead. */
export type OneTimePasswordNotVerified = MfaNotVerified;

export type MfaKeyNotFound = LibSignalErrorCommon & {
  code: ErrorCode.MfaKeyNotFound;
};

export type WebAuthnRegistrationUnsuccessful = LibSignalErrorCommon & {
  code: ErrorCode.WebAuthnRegistrationUnsuccessful;
};

export type LibSignalError =
  | GenericError
  | DuplicatedMessageError
  | SealedSenderSelfSendError
  | UntrustedIdentityError
  | InvalidRegistrationIdError
  | InvalidProtocolAddress
  | VerificationFailedError
  | InvalidSessionError
  | InvalidSenderKeySessionError
  | NicknameCannotBeEmptyError
  | CannotStartWithDigitError
  | MissingSeparatorError
  | BadNicknameCharacterError
  | NicknameTooShortError
  | NicknameTooLongError
  | DiscriminatorCannotBeEmptyError
  | DiscriminatorCannotBeZeroError
  | DiscriminatorCannotBeSingleDigitError
  | DiscriminatorCannotHaveLeadingZerosError
  | BadDiscriminatorCharacterError
  | DiscriminatorTooLargeError
  | InputDataTooLong
  | InvalidEntropyDataLength
  | InvalidUsernameLinkEncryptedData
  | IoError
  | CdsiInvalidTokenError
  | InvalidUriError
  | InvalidMediaInputError
  | SvrDataMissingError
  | SvrRestoreFailedError
  | SvrRequestFailedError
  | SvrAttestationError
  | SvrInvalidDataError
  | SvrDataMismatchError
  | UnsupportedMediaInputError
  | ChatServiceInactive
  | AppExpiredError
  | DeviceDelinkedError
  | ConnectionInvalidatedError
  | ConnectedElsewhereError
  | PossibleCaptiveNetworkError
  | RateLimitedError
  | RateLimitChallengeError
  | BackupValidationError
  | CancellationError
  | KeyTransparencyError
  | KeyTransparencyVerificationFailed
  | IncrementalMacVerificationFailed
  | RequestUnauthorizedError
  | MismatchedDevicesError
  | ServiceIdNotFound
  | UploadTooLarge
  | RegistrationSessionNotFoundError
  | RegistrationSessionIdInvalidError
  | RegistrationRequestInvalidError
  | RegistrationRequestRejectedError
  | RegistrationSessionNotReadyForVerificationError
  | RegistrationVerificationSendFailedError
  | RegistrationVerificationCodeNotDeliverableError
  | RegistrationLockError
  | RegistrationDeviceTransferPossibleNotSkippedError
  | RegistrationOneTimePasswordRequiredError
  | RegistrationRecoveryPasswordRequiredError
  | RegistrationRecoveryVerificationFailedError
  | RegisterAccountRequestRejectedError
  | RegistrationCredentialsCouldNotBeParsedError
  | RegistrationInvalidSessionError
  | RegistrationInvalidReceiptError
  | DeviceIdNotFound
  | UsernameNotAvailable
  | UsernameNotSet
  | UsernameReservationNotFound
  | InvalidReceiptError
  | MissingBackupId
  | ReceiptCredentialErrorPaymentStillProcessing
  | ReceiptCredentialErrorPaymentRequired
  | ReceiptCredentialErrorPaymentNotFound
  | ReceiptCredentialErrorReceiptAlreadyIssued
  | TooManyTotpKeys
  | TooManyMfaKeys
  | MfaNotVerified
  | MfaKeyNotFound
  | WebAuthnRegistrationUnsuccessful;
