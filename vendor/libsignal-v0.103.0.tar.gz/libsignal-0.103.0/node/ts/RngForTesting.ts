//
// Copyright 2026 Signal Messenger, LLC.
// SPDX-License-Identifier: AGPL-3.0-only
//

export type Rng = {
  __deterministicRngSeedForTesting: number;
};
